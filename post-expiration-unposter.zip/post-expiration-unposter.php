<?php
/*
Plugin Name: Post Expiration Unposter
Description: Automatically unpublishes posts on their expiration date.
Version: 0.2
Author: AlecWilcoxMedia
Text Domain: post-expiration-unposter
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Activation: schedule daily event
 */
function peu_activate() {
    if (!wp_next_scheduled('peu_daily_event')) {
        wp_schedule_event(time(), 'daily', 'peu_daily_event');
    }
}
register_activation_hook(__FILE__, 'peu_activate');

/**
 * Deactivation: clear scheduled event
 */
function peu_deactivate() {
    wp_clear_scheduled_hook('peu_daily_event');
}
register_deactivation_hook(__FILE__, 'peu_deactivate');

/**
 * Daily event hook: check and unpublish expired posts
 */
add_action('peu_daily_event', 'peu_check_expired_posts');
function peu_check_expired_posts() {
    $today = date('Y-m-d');
    $args = array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'meta_query'     => array(
            array(
                'key'     => '_peu_expiration_date',
                'value'   => $today,
                'compare' => '<=',
                'type'    => 'DATE',
            ),
        ),
        'posts_per_page' => -1,
    );
    $query = new WP_Query($args);
    if ($query->have_posts()) {
        foreach ($query->posts as $post) {
            wp_update_post(array(
                'ID'          => $post->ID,
                'post_status' => 'draft',
            ));
        }
    }
    wp_reset_postdata();
}

/**
 * Add expiration date meta box
 */
add_action('add_meta_boxes', 'peu_add_meta_box');
function peu_add_meta_box() {
    add_meta_box(
        'peu_meta_box',
        __('Expiration Date', 'post-expiration-unposter'),
        'peu_meta_box_callback',
        'post',
        'side',
        'default'
    );
}

function peu_meta_box_callback($post) {
    wp_nonce_field('peu_save_meta', 'peu_meta_nonce');
    $value = get_post_meta($post->ID, '_peu_expiration_date', true);
    echo '<label for="peu_expiration_date">' . __('Select expiration date:', 'post-expiration-unposter') . '</label> ';
    echo '<input type="date" id="peu_expiration_date" name="peu_expiration_date" value="' . esc_attr($value) . '" style="width:100%"/>';
}

/**
 * Save expiration date meta
 */
add_action('save_post', 'peu_save_meta_box_data');
function peu_save_meta_box_data($post_id) {
    if (!isset($_POST['peu_meta_nonce']) || !wp_verify_nonce($_POST['peu_meta_nonce'], 'peu_save_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (isset($_POST['peu_expiration_date'])) {
        $date = sanitize_text_field($_POST['peu_expiration_date']);
        if ($date) {
            update_post_meta($post_id, '_peu_expiration_date', $date);
        } else {
            delete_post_meta($post_id, '_peu_expiration_date');
        }
    }
}
